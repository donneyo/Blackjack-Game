//This example is to test the if...else statement
/*let score = 2000;

if (score > 1000){
  score = score +100;}
else if (score ===1000)
  console.log("Almost!");
else
  console.log("Nice try!");
  
  console.log("scores is:  "+ score);*/


//This example is to test the switch case condition

/*  let state = 'TX';
  
  switch (state) {
    
    case 'NY':
      console.log('newyork city');
    break;
    
    case 'TX':
        console.log('Texas');
        console.log('lagos');
      //allow fallthrough
    
    default:
    console.log('unknown');
    break;
  }*/

//This example is for for-loop
/*
for (i=0;i<5;i++){
  console.log(i);
}*/

//This is an example for while-loop

/*let  count = 0;
  
while (count <=3){
  console.log(count);
  count++;
}*/

//creating nested loop

/*
let surname = ['salami','idowu','eshenake','shittu'];
let firstName = ['adeniyi','adedji','toyin','kenny','tee','mary','anita','happiness','nancy','debby'];
  
let fullName = [];
  
  for( let surnameidx = 0; surnameidx < surname.length; surnameidx++){
    
    for ( let firstNameidx = 0; firstNameidx < firstName.length; firstNameidx++)
    {
      fullName.push(surname[surnameidx] + ' ' + firstName[firstNameidx] );
    }
  }
  
  for  ( let i = 0; i < fullName.length ; i++){
    console.log(fullName[i]);
  }
  */


//calling a function 
/*
function myFunction(message, firstNumber) {
  message = message + ' world!';
  firstNumber = firstNumber + '/06/2019';
  console.log(message, firstNumber);
}
myFunction('Hello', 26);
*/
/*
//trying out calling function
 function myFunction(favouriteNumber){
   newNumber = favouriteNumber + 100;
   return newNumber;
 }
  result = myFunction(42);
console.log(result);
*/
/*
//creating an object
let card ={
  surname: "salami",
  firstname: "Adeniy",
};
console.log(card.surname);
console.log(card.firstname);
*/
/*


//creating arrays of objects
let cards =[
  {
  suits: "heart",
  values: "queen",
  },
    {
  suits: "king",
  values: "rook",
  }
];
console.log(cards[1].suits)
*/

//using javvascript built in oject
/*let result = Math.random() * 52;
result = Math.trunc(result);

console.log(result);*/

/*let result = new Date().toDateString();
let adeniyi = "Todays date is: " + result 


console.log(adeniyi);*/



 /*
creating blackjack game

let suits = ['Hearts', 'Clubs', 'Diamond', 'Spades']; //declaring suits
let values = ['Ace', 'King', 'Queen', 'Jack', 'Ten', 'Nine', 'Eight', 'Seven',
  'Six', 'Five', 'Four', 'Three', 'Two'
]; //declaring values



function createDeck() { //creating deck of cards
  let deck = []; //creating an empty deck where cards would be stored
  for (let suitIdx = 0; suitIdx < suits.length; suitIdx++) { //looping  through the suit declared above
    for (let valueIdx = 0; valueIdx < values.length; valueIdx++) // looping  through the values declared above
    {
      let card = { //creating and defining an object called card in value
        suit: suits[suitIdx], //propertiy and value                      
        value: values[valueIdx] //property and value
      };
      deck.push( card ); //pushing card into deck declared
    }
  }
  return deck; //return deck very important to run 
}


function getCardString(card) //i don't really understand why card was pass as argument here   
{
  return card.value + ' of ' + card.suit;
}

function getNextCard() {
  return deck.shift();
}


let deck = createDeck();


let playerCards= [getNextCard(), getNextCard(), getNextCard()];


console.log("Welcome to Blackjack!");

console.log("You are dealt: ");
console.log(" " + getCardString(playerCards[0]));
console.log(" " + getCardString(playerCards[1]));
console.log(" " + getCardString(playerCards[2]));
*/
//creating blackjack game
//Card variables
let suits = ['Hearts', 'Clubs', 'Diamond', 'Spades']; //declaring suits
let values = ['Ace', 'King', 'Queen', 'Jack', 'Ten', 'Nine', 'Eight', 'Seven',
  'Six', 'Five', 'Four', 'Three', 'Two'
]; //declaring card values

//DOM variables
let textArea = document.getElementById('text-area');
let newGameButton = document.getElementById('new-game-button');
let hitButton = document.getElementById('hit-button');
let stayButton = document.getElementById('stay-button');


//Game variables
let gameStarted = false;
let gameOver = false;
let playerWon = false;
let dealerCards = [];
let playerCards = [];
let playerScore = 0;
let dealerScore =0;
let deck = [];

hitButton.style.display ='none';
stayButton.style.display ='none';
showStatus();

newGameButton.addEventListener('click', function(){
  gameStarted = true;
  gameOver = false;
  playerWon = false;
  
  deck  = createDeck();
  shuffleDeck(deck);
  dealerCards = [ getNextCard(), getNextCard()];
  playerCards = [ getNextCard(), getNextCard()];
  
  newGameButton.style.display ='none';
  hitButton.style.display ='inline';
  stayButton.style.display ='inline'; 
  showStatus();
  });

hitButton.addEventListener('click', function() {
    playerCards.push(getNextCard());
    checkForEndOfGame();
    showStatus(); 
});
  
 stayButton.addEventListener('click', function() {
    gameOver = true;
    checkForEndOfGame();
    showStatus();
 });
  
  
function createDeck() { 
  let deck = [];
  for (let suitIdx = 0; suitIdx < suits.length; suitIdx++) { 
    for (let valueIdx = 0; valueIdx < values.length; valueIdx++) 
    {
      let card = { 
        suit: suits[suitIdx],                     
        value: values[valueIdx] 
      };
      deck.push( card );
    }
  }
  return deck; 
}

function shuffleDeck(deck){
  for (let i = 0; i < deck.length; i++){
    let swapIdx = Math.trunc(Math.random() * deck.length);
    let tmp = deck[swapIdx];
    deck[swapIdx] = deck[i];
    deck[i] = tmp;
  }
}
function getCardString(card) //i don't really understand why card was pass as argument here   
{
  return card.value + ' of ' + card.suit;
}

function getNextCard() {
  return deck.shift();
}
function getCardNumericValue(card){
  switch(card.value) {
    case 'Ace':
      return 1;
    case 'Two':
      return 2;
    case 'Three':
      return 3;
    case 'Four':
      return 4;
    case 'Five':
      return 5;
    case 'Six':
      return 6;
    case 'Seven':
      return 7;
    case 'Eight':
      return 8;
    case 'Nine':
      return 9;
    default:
      return 10;
  }
}


function getScore(cardArray){
  let score = 0;
  let hasAce = false;
  for (let i = 0; i < cardArray.length; i ++){
    let card = cardArray[i];
    score += getCardNumericValue(card);
    if(card.value==='Ace'){
      hasAce = true;
    }
  }
  if (hasAce && score + 10 <= 21){
    return score + 10;
  }
  return score;
}



function updateScores(){
  dealerScore = getScore(dealerCards);
  playerScore = getScore(playerCards);
}

function checkForEndOfGame(){
  
  updateScores();
  if (gameOver){
    //let dealer take cards
    while(dealerScore < playerScore
         && playerScore <= 21
         && dealerScore <= 21){
      dealerCards.push(getNextCard());
      updateScores();
    }
  }
  if(playerScore > 21){
     playerWon =false;
     gameOver = true; 
     }
  
   else if (dealerScore > 21 ){
     playerWon = true;
     gameOver  = true;
   } 
  
   else if (gameOver){
     
     if(playerScore > dealerScore){
       playerWon = true;
     }
     
     else {
       playerWon = false;
     }
   }  
} 

function showStatus(){
  if (!gameStarted){
    textArea.innerText ='Welcome to Blackjack!';
    return;
  }
  let dealerCardString = '';
  for (let i=0; i< dealerCards.length; i++){
    dealerCardString += getCardString(dealerCards[i]) + '\n';
  }
  let playerCardString = '';
  for (let i =0 ; i < playerCards.length; i++){
    playerCardString += getCardString(playerCards[i]) + '\n';
  }

   updateScores();
  
  textArea.innerText =
    'Dealer has: \n' +
    dealerCardString +
    '(score: '+ dealerScore + ')\n\n' +
    
    'Player has:\n' +
    playerCardString +
    '(score: '+ playerScore +')\n\n';
  
  if(gameOver){
    if (playerWon) {
      textArea.innerText += "DONNEYO WIN!";
    }
    else if(playerScore === dealerScore){
      textArea.innerText += "WE HAVE A TIE! ";
    }
    else{
      textArea.innerText += "COMPUTER WIN! ";
    }
    newGameButton.style.display ='inline';
    hitButton.style.display ='none';
    stayButton.style.display ='none';
  } 
}

